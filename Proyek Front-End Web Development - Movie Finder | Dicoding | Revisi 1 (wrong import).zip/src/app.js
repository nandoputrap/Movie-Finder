import "./styles/style.css";
import "./script/component/app-bar.js";
import "./script/component/student-note.js";